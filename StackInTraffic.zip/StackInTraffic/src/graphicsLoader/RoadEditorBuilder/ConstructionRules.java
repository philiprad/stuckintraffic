/*
 * @author  Maxim Vasilishin
 * @version 1.0
 */
package graphicsLoader.RoadEditorBuilder;

/**
 * The Class ConstructionRules.
 */
public class ConstructionRules {

}
